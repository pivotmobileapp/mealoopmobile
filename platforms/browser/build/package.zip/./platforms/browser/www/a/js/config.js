angular.module('your_app_name.config', [])
.constant('WORDPRESS_API_URL', 'http://mealoop.com/main/wp-json/wp/v2/')
.constant('WORDPRESS_PUSH_URL', 'https://wordpress.startapplabs.com/blog/push/')
.constant('GCM_SENDER_ID', '574597432927')

;
